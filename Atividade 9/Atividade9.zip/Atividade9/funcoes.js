function maiorDeTres(a, b, c) {
  let maior = a;
  if (b > maior) maior = b;
  if (c > maior) maior = c;
  return maior;
}

function ordenarCrescente(a, b, c) {
  return [a, b, c].sort(function (x, y) {
    return x - y;
  });
}

function ehPalindromo(texto) {
  if (typeof texto !== "string") return false;
  const limpo = texto.toLowerCase().replace(/\s/g, "");
  const invertido = limpo.split("").reverse().join("");
  return limpo === invertido;
}

function verificarSubconjunto(palavra1, palavra2) {
  const invalida = function (p) {
    return typeof p !== "string" || p.trim() === "";
  };

  if (invalida(palavra1) || invalida(palavra2)) {
    return "erro";
  }

  const p1 = palavra1.trim().toLowerCase();
  const p2 = palavra2.trim().toLowerCase();

  return p1.includes(p2) ? "é um subconjunto" : "não é um subconjunto";
}

function diaDaSemana(data) {
  const dias = [
    "Domingo",
    "Segunda-feira",
    "Terça-feira",
    "Quarta-feira",
    "Quinta-feira",
    "Sexta-feira",
    "Sábado"
  ];

  let d;
  if (typeof data === "string") {
    const partes = data.split("-").map(Number);
    if (partes.length !== 3 || partes.some(isNaN)) return "data inválida";
    d = new Date(partes[0], partes[1] - 1, partes[2]);
  } else {
    d = data;
  }

  if (!(d instanceof Date) || isNaN(d)) return "data inválida";

  return dias[d.getDay()];
}
