// Jogo: Pedra, Papel ou Tesoura (usuário x computador)

const opcoes = ["pedra", "papel", "tesoura"];

const emojis = {
  pedra: "✊",
  papel: "✋",
  tesoura: "✌️"
};

// Regras: chave vence o valor
// Pedra quebra tesoura / Tesoura corta papel / Papel cobre pedra
const regras = {
  pedra: { vence: "tesoura", frase: "Pedra quebra tesoura." },
  tesoura: { vence: "papel", frase: "Tesoura corta papel." },
  papel: { vence: "pedra", frase: "Papel cobre pedra." }
};

let placar = { vitorias: 0, empates: 0, derrotas: 0 };

// Fase B: o computador faz uma escolha.
// Math.random() devolve um número em [0, 1): inclui 0 e nunca chega a 1.
// Multiplicando por 3 e usando Math.floor, obtém-se 0, 1 ou 2.
// (equivale a dividir 0.99 em 3 partes: 0-0.33, 0.33-0.66, 0.66-0.99)
function escolherComputador() {
  const indice = Math.floor(Math.random() * 3);
  return opcoes[indice];
}

// Fase C: a partir das duas escolhas, determina o vencedor.
function determinarVencedor(escolhaUsuario, escolhaComputador) {
  if (escolhaUsuario === escolhaComputador) {
    return { vencedor: "empate", mensagem: "Empate!" };
  }

  if (regras[escolhaUsuario].vence === escolhaComputador) {
    return { vencedor: "usuario", mensagem: regras[escolhaUsuario].frase + " Você ganhou! 🎉" };
  }

  return { vencedor: "computador", mensagem: regras[escolhaComputador].frase + " O computador ganhou! 🤖" };
}

function atualizarPlacar() {
  document.querySelector("#vitorias").textContent = placar.vitorias;
  document.querySelector("#empates").textContent = placar.empates;
  document.querySelector("#derrotas").textContent = placar.derrotas;
}

// Fase A: o usuário faz uma escolha (clique no botão).
function jogar(escolhaUsuario) {
  const escolhaComputador = escolherComputador();
  const resultado = determinarVencedor(escolhaUsuario, escolhaComputador);

  document.querySelector("#escolhaUsuario").textContent = emojis[escolhaUsuario];
  document.querySelector("#escolhaComputador").textContent = emojis[escolhaComputador];

  const elementoResultado = document.querySelector("#resultado");
  elementoResultado.textContent = resultado.mensagem;
  elementoResultado.className = "resultado " + resultado.vencedor;

  if (resultado.vencedor === "usuario") {
    placar.vitorias++;
  } else if (resultado.vencedor === "computador") {
    placar.derrotas++;
  } else {
    placar.empates++;
  }

  atualizarPlacar();
}

function reiniciarPlacar() {
  placar = { vitorias: 0, empates: 0, derrotas: 0 };
  atualizarPlacar();
  document.querySelector("#escolhaUsuario").textContent = "❔";
  document.querySelector("#escolhaComputador").textContent = "❔";
  const elementoResultado = document.querySelector("#resultado");
  elementoResultado.textContent = "Escolha uma opção para começar.";
  elementoResultado.className = "resultado";
}

document.querySelectorAll(".escolhas button").forEach((botao) => {
  botao.addEventListener("click", () => jogar(botao.dataset.escolha));
});

document.querySelector("#reiniciar").addEventListener("click", reiniciarPlacar);
